<?php

namespace Wearesho\Phonet\Yii;

/**
 * Class Identity
 * @package Wearesho\Phonet\Yii
 */
abstract class Identity implements IdentityInterface
{
    use IdentityTrait;
}
