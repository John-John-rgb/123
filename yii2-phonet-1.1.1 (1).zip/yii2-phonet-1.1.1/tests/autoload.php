<?php

require_once(__DIR__ . '/constants.php');
require_once(dirname(__DIR__) . '/vendor/autoload.php');
require_once(dirname(__DIR__) . '/vendor/yiisoft/yii2/Yii.php');
require_once(__DIR__ . '/bootstrap.php');
