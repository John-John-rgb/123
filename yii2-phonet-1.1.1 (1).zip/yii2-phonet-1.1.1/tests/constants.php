<?php

defined('YII_DEBUG') || define("YII_DEBUG", getenv("YII_DEBUG") ?: true);
defined('YII_ENV') || define("YII_ENV", getenv("YII_ENV") ?: "test");
